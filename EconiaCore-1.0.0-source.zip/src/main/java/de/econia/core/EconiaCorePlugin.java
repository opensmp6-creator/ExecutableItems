package de.econia.core;

import de.econia.core.command.EconiaCommand;
import de.econia.core.listener.ChatListener;
import de.econia.core.listener.ConnectionListener;
import de.econia.core.listener.JobListener;
import de.econia.core.listener.PlotProtectionListener;
import de.econia.core.service.DisplayService;
import de.econia.core.service.MarketService;
import de.econia.core.service.PlayerDataService;
import de.econia.core.service.PlotService;
import de.econia.core.service.PunishmentService;
import de.econia.core.service.YamlStorage;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/** Hauptklasse des eigenständigen Econia-Serverplugins. */
public final class EconiaCorePlugin extends JavaPlugin {
    private PlayerDataService playerData;
    private PunishmentService punishments;
    private PlotService plots;
    private MarketService market;
    private DisplayService displays;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        playerData = new PlayerDataService(new YamlStorage(this, "players.yml"));
        punishments = new PunishmentService(this, new YamlStorage(this, "punishments.yml"));
        plots = new PlotService(this, new YamlStorage(this, "plots.yml"));
        market = new MarketService(this, new YamlStorage(this, "market.yml"));
        displays = new DisplayService(this);

        EconiaCommand command = new EconiaCommand(this);
        List<String> commandNames = List.of("punisch", "rang", "geld", "gems", "pay", "eco", "job", "markt", "kiste",
                "plot", "sethome", "home", "delhome", "setwarp", "warp", "delwarp", "heal", "fly", "repair");
        for (String commandName : commandNames) {
            PluginCommand registered = getCommand(commandName);
            if (registered == null) {
                getLogger().severe("Befehl fehlt in plugin.yml: " + commandName);
                continue;
            }
            registered.setExecutor(command);
            registered.setTabCompleter(command);
        }

        getServer().getPluginManager().registerEvents(new ConnectionListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new JobListener(this), this);
        getServer().getPluginManager().registerEvents(new PlotProtectionListener(this), this);

        long interval = Math.max(1L, getConfig().getLong("settings.autosave-minutes", 5L)) * 60L * 20L;
        getServer().getScheduler().runTaskTimer(this, this::saveAll, interval, interval);
        getLogger().info("EconiaCore wurde aktiviert.");
    }

    @Override
    public void onDisable() {
        saveAll();
    }

    private void saveAll() {
        if (playerData != null) {
            playerData.save();
            punishments.save();
            plots.save();
            market.save();
        }
    }

    public PlayerDataService getPlayerData() {
        return playerData;
    }

    public PunishmentService getPunishments() {
        return punishments;
    }

    public PlotService getPlots() {
        return plots;
    }

    public MarketService getMarket() {
        return market;
    }

    public DisplayService getDisplays() {
        return displays;
    }
}
