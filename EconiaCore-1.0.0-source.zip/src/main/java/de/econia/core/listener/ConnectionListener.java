package de.econia.core.listener;

import de.econia.core.EconiaCorePlugin;
import de.econia.core.service.PunishmentService;
import de.econia.core.util.Text;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Verhindert aktive Sperren und richtet neue Spieler ein. */
public final class ConnectionListener implements Listener {
    private final EconiaCorePlugin plugin;

    public ConnectionListener(EconiaCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onLogin(PlayerLoginEvent event) {
        PunishmentService.ActivePunishment punishment = plugin.getPunishments().getActive(event.getPlayer().getUniqueId());
        if (punishment == null) {
            return;
        }
        event.disallow(PlayerLoginEvent.Result.KICK_BANNED, Text.color(punishment.disconnectMessage()));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getPlayerData().ensurePlayer(event.getPlayer().getUniqueId(), event.getPlayer().getName());
        plugin.getServer().getScheduler().runTask(plugin, plugin.getDisplays()::refreshAll);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getServer().getScheduler().runTask(plugin, plugin.getDisplays()::refreshAll);
    }
}
