package de.econia.core.listener;

import de.econia.core.EconiaCorePlugin;
import de.econia.core.model.Rank;
import de.econia.core.util.Text;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

/** Formatiert den öffentlichen Chat mit dem konfigurierten Econia-Prefix. */
@SuppressWarnings("deprecation")
public final class ChatListener implements Listener {
    private final EconiaCorePlugin plugin;

    public ChatListener(EconiaCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Rank rank = plugin.getPlayerData().getRank(event.getPlayer().getUniqueId());
        String prefix = Text.color(rank.getPrefix(plugin.getConfig()));
        String chatColor = Text.color(rank.getChatColor(plugin.getConfig()));
        event.setFormat(prefix + "%1$s &8» " + chatColor + "%2$s");
    }
}
