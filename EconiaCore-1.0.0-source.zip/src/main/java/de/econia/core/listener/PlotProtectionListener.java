package de.econia.core.listener;

import de.econia.core.EconiaCorePlugin;
import de.econia.core.util.Text;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;

/** Verhindert Bauen, Abbauen und Interaktionen auf nicht freigegebenen Plots. */
public final class PlotProtectionListener implements Listener {
    private final EconiaCorePlugin plugin;

    public PlotProtectionListener(EconiaCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent event) {
        protect(event.getPlayer(), event.getBlock(), event);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent event) {
        protect(event.getPlayer(), event.getBlockPlaced(), event);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() != null && !plugin.getPlots().canBuild(event.getPlayer(), event.getClickedBlock().getLocation())) {
            event.setCancelled(true);
            Text.error(event.getPlayer(), "Dieses Grundstück gehört dir nicht.");
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(block -> plugin.getPlots().getPlotAt(block.getLocation()) != null);
    }

    private void protect(Player player, Block block, org.bukkit.event.Cancellable event) {
        if (!plugin.getPlots().canBuild(player, block.getLocation())) {
            event.setCancelled(true);
            Text.error(player, "Dieses Grundstück gehört dir nicht.");
        }
    }
}
