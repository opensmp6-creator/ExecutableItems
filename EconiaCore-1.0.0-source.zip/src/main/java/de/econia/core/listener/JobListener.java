package de.econia.core.listener;

import de.econia.core.EconiaCorePlugin;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerFishEvent;

/** Vergütet passende Tätigkeiten des jeweils ausgewählten Jobs. */
public final class JobListener implements Listener {
    private final EconiaCorePlugin plugin;

    public JobListener(EconiaCorePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        reward(event.getPlayer(), event.getBlock().getType());
    }

    @EventHandler(ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() == PlayerFishEvent.State.CAUGHT_FISH && event.getCaught() instanceof Item item) {
            reward(event.getPlayer(), item.getItemStack().getType());
        }
    }

    private void reward(Player player, Material material) {
        String job = plugin.getPlayerData().getJob(player.getUniqueId());
        if (job.isBlank()) {
            return;
        }
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("jobs." + job);
        if (section == null) {
            return;
        }
        Material required = Material.matchMaterial(section.getString("material", "AIR"));
        if (required != material) {
            return;
        }
        plugin.getPlayerData().addCoins(player.getUniqueId(), section.getDouble("payout", 0.0D));
    }
}
