package de.econia.core.model;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Locale;

/**
 * Rangfolge von Econia. Die sichtbaren Texte, Prefixe und Limits stammen aus config.yml.
 */
public enum Rank {
    SPIELER(false),
    PREMIUM(false),
    DIAMOND(false),
    ULTRA(false),
    LEGENDE(false),
    SUPREME(false),
    PLATIN(false),
    OP(false),
    SUPPORTER(true),
    MODERATOR(true),
    ADMINISTRATOR(true),
    OWNER(true);

    private final boolean staff;

    Rank(boolean staff) {
        this.staff = staff;
    }

    public boolean isStaff() {
        return staff;
    }

    public boolean isAtLeast(Rank other) {
        return getWeight(null) >= other.getWeight(null);
    }

    public boolean canPunish() {
        return this == MODERATOR || this == ADMINISTRATOR || this == OWNER;
    }

    public boolean canManageRanks() {
        return this == ADMINISTRATOR || this == OWNER;
    }

    public int getWeight(FileConfiguration config) {
        if (config == null) {
            return ordinal();
        }
        return config.getInt("ranks." + name() + ".weight", ordinal());
    }

    public String getPrefix(FileConfiguration config) {
        return config.getString("ranks." + name() + ".prefix", "&7[" + getDisplay(config) + "] ");
    }

    public String getTabPrefix(FileConfiguration config) {
        return config.getString("ranks." + name() + ".tab-prefix", getPrefix(config));
    }

    public String getDisplay(FileConfiguration config) {
        return config.getString("ranks." + name() + ".display", name());
    }

    public String getChatColor(FileConfiguration config) {
        return config.getString("ranks." + name() + ".chat-color", "&7");
    }

    public int getHomes(FileConfiguration config) {
        return config.getInt("ranks." + name() + ".homes", 1);
    }

    public int getPlots(FileConfiguration config) {
        return config.getInt("ranks." + name() + ".plots", 1);
    }

    public static Rank fromInput(String input) {
        if (input == null || input.isBlank()) {
            return SPIELER;
        }
        String normalized = input.trim()
                .toUpperCase(Locale.ROOT)
                .replace('Ä', 'A')
                .replace('Ö', 'O')
                .replace('Ü', 'U')
                .replace('ß', 'S')
                .replace('-', '_')
                .replace(' ', '_');
        if (normalized.equals("ADMIN") || normalized.equals("ADMINISTRATOR")) {
            return ADMINISTRATOR;
        }
        try {
            return Rank.valueOf(normalized);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }
}
