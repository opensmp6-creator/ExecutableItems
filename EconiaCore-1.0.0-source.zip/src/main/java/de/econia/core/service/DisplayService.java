package de.econia.core.service;

import de.econia.core.EconiaCorePlugin;
import de.econia.core.model.Rank;
import de.econia.core.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/** Erzeugt die persönliche Tablist und Sidebar für jeden Online-Spieler. */
public final class DisplayService {
    private final EconiaCorePlugin plugin;

    public DisplayService(EconiaCorePlugin plugin) {
        this.plugin = plugin;
    }

    public void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            refresh(player);
        }
    }

    public void refresh(Player player) {
        Rank rank = plugin.getPlayerData().getRank(player.getUniqueId());
        player.setPlayerListName(Text.color(rank.getTabPrefix(plugin.getConfig()) + player.getName()));
        player.setPlayerListHeaderFooter(
                Text.color("&6&lECONIA\n&7CityBuild &8| &f" + Bukkit.getOnlinePlayers().size() + " &7online"),
                Text.color("&7Viel Spaß auf &6Econia")
        );

        Scoreboard scoreboard = player.getScoreboard();
        if (scoreboard == Bukkit.getScoreboardManager().getMainScoreboard()) {
            scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
            player.setScoreboard(scoreboard);
        }
        refreshTeams(scoreboard);
        refreshSidebar(player, scoreboard, rank);
    }

    private void refreshTeams(Scoreboard scoreboard) {
        for (Player listed : Bukkit.getOnlinePlayers()) {
            Rank listedRank = plugin.getPlayerData().getRank(listed.getUniqueId());
            String teamName = String.format("%03d_%s", 999 - listedRank.getWeight(plugin.getConfig()), listedRank.name().substring(0, 1));
            if (teamName.length() > 16) {
                teamName = teamName.substring(0, 16);
            }
            Team desired = scoreboard.getTeam(teamName);
            if (desired == null) {
                desired = scoreboard.registerNewTeam(teamName);
                desired.setPrefix(Text.color(listedRank.getTabPrefix(plugin.getConfig())));
            }
            for (Team other : scoreboard.getTeams()) {
                if (other.hasEntry(listed.getName()) && !other.getName().equals(teamName)) {
                    other.removeEntry(listed.getName());
                }
            }
            desired.addEntry(listed.getName());
        }
    }

    private void refreshSidebar(Player player, Scoreboard scoreboard, Rank rank) {
        Objective objective = scoreboard.getObjective("econia");
        if (objective == null) {
            objective = scoreboard.registerNewObjective("econia", Criteria.DUMMY, Text.color(plugin.getConfig().getString("server.scoreboard-title", "&6&lECONIA")));
            objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        }
        for (String entry : scoreboard.getEntries()) {
            scoreboard.resetScores(entry);
        }

        setScore(objective, Text.color("&8"), 8);
        setScore(objective, Text.color("&7Name: &f" + player.getName()), 7);
        setScore(objective, Text.color("&7Rang: " + rank.getPrefix(plugin.getConfig()).trim()), 6);
        setScore(objective, Text.color("&1"), 5);
        setScore(objective, Text.color("&7Coins: &6" + format(plugin.getPlayerData().getCoins(player.getUniqueId()))), 4);
        setScore(objective, Text.color("&7Gems: &b" + plugin.getPlayerData().getGems(player.getUniqueId())), 3);
        setScore(objective, Text.color("&2"), 2);
        setScore(objective, Text.color("&7Online: &a" + Bukkit.getOnlinePlayers().size()), 1);
        setScore(objective, Text.color("&6econia"), 0);
    }

    private void setScore(Objective objective, String text, int score) {
        objective.getScore(text).setScore(score);
    }

    private String format(double number) {
        if (number == Math.rint(number)) {
            return String.format("%,.0f", number);
        }
        return String.format("%,.2f", number);
    }
}
