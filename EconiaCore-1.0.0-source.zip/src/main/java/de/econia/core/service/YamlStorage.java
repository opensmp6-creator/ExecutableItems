package de.econia.core.service;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

/** Einfache, synchrone YAML-Ablage für die kleinen Econia-Serverdaten. */
public final class YamlStorage {
    private final JavaPlugin plugin;
    private final File file;
    private YamlConfiguration configuration;

    public YamlStorage(JavaPlugin plugin, String fileName) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), fileName);
        reload();
    }

    public void reload() {
        if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
            plugin.getLogger().warning("Datenordner konnte nicht erstellt werden: " + plugin.getDataFolder());
        }
        configuration = YamlConfiguration.loadConfiguration(file);
    }

    public YamlConfiguration data() {
        return configuration;
    }

    public void save() {
        try {
            configuration.save(file);
        } catch (IOException exception) {
            plugin.getLogger().log(Level.SEVERE, "Daten konnten nicht gespeichert werden: " + file.getName(), exception);
        }
    }
}
