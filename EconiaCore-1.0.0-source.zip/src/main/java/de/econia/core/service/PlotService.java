package de.econia.core.service;

import de.econia.core.EconiaCorePlugin;
import de.econia.core.model.Rank;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Speichert quadratische CityBuild-Grundstücke und ihre Zugriffslisten. */
public final class PlotService {
    private final EconiaCorePlugin plugin;
    private final YamlStorage storage;

    public PlotService(EconiaCorePlugin plugin, YamlStorage storage) {
        this.plugin = plugin;
        this.storage = storage;
    }

    public ClaimResult claim(Player player) {
        Rank rank = plugin.getPlayerData().getRank(player.getUniqueId());
        if (getOwnedPlots(player.getUniqueId()).size() >= rank.getPlots(plugin.getConfig())) {
            return ClaimResult.limitReached(rank.getPlots(plugin.getConfig()));
        }
        double price = plugin.getConfig().getDouble("settings.plot-price", 2500.0D);
        if (plugin.getPlayerData().getCoins(player.getUniqueId()) < price) {
            return ClaimResult.notEnoughMoney(price);
        }
        int size = Math.max(16, plugin.getConfig().getInt("settings.plot-size", 32));
        int minX = Math.floorDiv(player.getLocation().getBlockX(), 16) * 16;
        int minZ = Math.floorDiv(player.getLocation().getBlockZ(), 16) * 16;
        Plot proposed = new Plot(UUID.randomUUID().toString(), player.getUniqueId(), player.getWorld().getName(), minX, minX + size - 1, minZ, minZ + size - 1, new ArrayList<>());
        for (Plot existing : getAll()) {
            if (proposed.overlaps(existing)) {
                return ClaimResult.overlaps();
            }
        }
        plugin.getPlayerData().withdrawCoins(player.getUniqueId(), price);
        write(proposed);
        storage.save();
        return ClaimResult.success(proposed, price);
    }

    public Plot getPlotAt(Location location) {
        if (location.getWorld() == null) {
            return null;
        }
        for (Plot plot : getAll()) {
            if (plot.contains(location)) {
                return plot;
            }
        }
        return null;
    }

    public boolean deleteAt(Player player) {
        Plot plot = getPlotAt(player.getLocation());
        if (plot == null || !plot.owner().equals(player.getUniqueId())) {
            return false;
        }
        storage.data().set("plots." + plot.id(), null);
        storage.save();
        return true;
    }

    public TrustResult trust(Player owner, String targetName) {
        Plot plot = getPlotAt(owner.getLocation());
        if (plot == null || !plot.owner().equals(owner.getUniqueId())) {
            return TrustResult.notOwner();
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            return TrustResult.unknownPlayer();
        }
        if (plot.owner().equals(target.getUniqueId())) {
            return TrustResult.alreadyTrusted();
        }
        if (plot.trusted().contains(target.getUniqueId())) {
            return TrustResult.alreadyTrusted();
        }
        List<UUID> trusted = new ArrayList<>(plot.trusted());
        trusted.add(target.getUniqueId());
        write(new Plot(plot.id(), plot.owner(), plot.world(), plot.minX(), plot.maxX(), plot.minZ(), plot.maxZ(), trusted));
        storage.save();
        return TrustResult.success(target.getName() == null ? targetName : target.getName());
    }

    public boolean untrust(Player owner, String targetName) {
        Plot plot = getPlotAt(owner.getLocation());
        if (plot == null || !plot.owner().equals(owner.getUniqueId())) {
            return false;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        List<UUID> trusted = new ArrayList<>(plot.trusted());
        if (!trusted.remove(target.getUniqueId())) {
            return false;
        }
        write(new Plot(plot.id(), plot.owner(), plot.world(), plot.minX(), plot.maxX(), plot.minZ(), plot.maxZ(), trusted));
        storage.save();
        return true;
    }

    public boolean canBuild(Player player, Location location) {
        if (player.hasPermission("econia.plot.bypass") || plugin.getPlayerData().getRank(player.getUniqueId()).canManageRanks()) {
            return true;
        }
        Plot plot = getPlotAt(location);
        return plot == null || plot.owner().equals(player.getUniqueId()) || plot.trusted().contains(player.getUniqueId());
    }

    public List<Plot> getOwnedPlots(UUID uuid) {
        return getAll().stream().filter(plot -> plot.owner().equals(uuid)).toList();
    }

    public List<Plot> getAll() {
        ConfigurationSection section = storage.data().getConfigurationSection("plots");
        if (section == null) {
            return List.of();
        }
        List<Plot> plots = new ArrayList<>();
        for (String id : section.getKeys(false)) {
            String path = "plots." + id;
            String world = storage.data().getString(path + ".world");
            String owner = storage.data().getString(path + ".owner");
            if (world == null || owner == null) {
                continue;
            }
            try {
                List<String> rawTrusted = storage.data().getStringList(path + ".trusted");
                List<UUID> trusted = rawTrusted.stream().map(this::asUuid).filter(uuid -> uuid != null).toList();
                plots.add(new Plot(id, UUID.fromString(owner), world,
                        storage.data().getInt(path + ".min-x"), storage.data().getInt(path + ".max-x"),
                        storage.data().getInt(path + ".min-z"), storage.data().getInt(path + ".max-z"), trusted));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Ungültiges Plot in plots.yml: " + id);
            }
        }
        return plots;
    }

    public void save() {
        storage.save();
    }

    private UUID asUuid(String raw) {
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    private void write(Plot plot) {
        String path = "plots." + plot.id();
        storage.data().set(path + ".owner", plot.owner().toString());
        storage.data().set(path + ".world", plot.world());
        storage.data().set(path + ".min-x", plot.minX());
        storage.data().set(path + ".max-x", plot.maxX());
        storage.data().set(path + ".min-z", plot.minZ());
        storage.data().set(path + ".max-z", plot.maxZ());
        storage.data().set(path + ".trusted", plot.trusted().stream().map(UUID::toString).toList());
    }

    public record Plot(String id, UUID owner, String world, int minX, int maxX, int minZ, int maxZ, List<UUID> trusted) {
        public boolean contains(Location location) {
            return location.getWorld() != null && world.equals(location.getWorld().getName())
                    && location.getBlockX() >= minX && location.getBlockX() <= maxX
                    && location.getBlockZ() >= minZ && location.getBlockZ() <= maxZ;
        }

        public boolean overlaps(Plot other) {
            return world.equals(other.world)
                    && minX <= other.maxX && maxX >= other.minX
                    && minZ <= other.maxZ && maxZ >= other.minZ;
        }
    }

    public record ClaimResult(boolean success, String message, Plot plot) {
        static ClaimResult success(Plot plot, double price) {
            return new ClaimResult(true, "Grundstück gekauft für " + String.format("%,.0f", price) + " Coins.", plot);
        }

        static ClaimResult limitReached(int limit) {
            return new ClaimResult(false, "Du hast dein Plot-Limit von " + limit + " erreicht.", null);
        }

        static ClaimResult notEnoughMoney(double price) {
            return new ClaimResult(false, "Du brauchst " + String.format("%,.0f", price) + " Coins für ein Grundstück.", null);
        }

        static ClaimResult overlaps() {
            return new ClaimResult(false, "Dieses Gebiet überschneidet sich mit einem bestehenden Grundstück.", null);
        }
    }

    public record TrustResult(boolean success, String message) {
        static TrustResult success(String name) {
            return new TrustResult(true, name + " wurde zum Grundstück hinzugefügt.");
        }

        static TrustResult notOwner() {
            return new TrustResult(false, "Du stehst auf keinem eigenen Grundstück.");
        }

        static TrustResult unknownPlayer() {
            return new TrustResult(false, "Dieser Spieler ist unbekannt.");
        }

        static TrustResult alreadyTrusted() {
            return new TrustResult(false, "Dieser Spieler ist bereits berechtigt.");
        }
    }
}
