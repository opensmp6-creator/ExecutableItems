package de.econia.core.service;

import de.econia.core.model.Rank;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.Collections;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Verwaltet alle spielerbezogenen Daten ohne eine externe Datenbank oder Permissions-Plugins. */
public final class PlayerDataService {
    private final YamlStorage storage;

    public PlayerDataService(YamlStorage storage) {
        this.storage = storage;
    }

    public void ensurePlayer(UUID uuid, String lastName) {
        String base = playerPath(uuid);
        if (!storage.data().contains(base + ".rank")) {
            storage.data().set(base + ".rank", Rank.SPIELER.name());
            storage.data().set(base + ".coins", 500.0D);
            storage.data().set(base + ".gems", 0);
        }
        storage.data().set(base + ".last-name", lastName);
    }

    public Rank getRank(UUID uuid) {
        Rank rank = Rank.fromInput(storage.data().getString(playerPath(uuid) + ".rank", Rank.SPIELER.name()));
        return rank == null ? Rank.SPIELER : rank;
    }

    public void setRank(UUID uuid, Rank rank) {
        storage.data().set(playerPath(uuid) + ".rank", rank.name());
    }

    public double getCoins(UUID uuid) {
        return storage.data().getDouble(playerPath(uuid) + ".coins", 500.0D);
    }

    public void setCoins(UUID uuid, double amount) {
        storage.data().set(playerPath(uuid) + ".coins", Math.max(0.0D, amount));
    }

    public void addCoins(UUID uuid, double amount) {
        setCoins(uuid, getCoins(uuid) + amount);
    }

    public boolean withdrawCoins(UUID uuid, double amount) {
        if (amount <= 0.0D || getCoins(uuid) + 0.0001D < amount) {
            return false;
        }
        setCoins(uuid, getCoins(uuid) - amount);
        return true;
    }

    public int getGems(UUID uuid) {
        return storage.data().getInt(playerPath(uuid) + ".gems", 0);
    }

    public void setGems(UUID uuid, int amount) {
        storage.data().set(playerPath(uuid) + ".gems", Math.max(0, amount));
    }

    public void addGems(UUID uuid, int amount) {
        setGems(uuid, getGems(uuid) + amount);
    }

    public boolean withdrawGems(UUID uuid, int amount) {
        if (amount <= 0 || getGems(uuid) < amount) {
            return false;
        }
        setGems(uuid, getGems(uuid) - amount);
        return true;
    }

    public String getJob(UUID uuid) {
        return storage.data().getString(playerPath(uuid) + ".job", "");
    }

    public void setJob(UUID uuid, String job) {
        storage.data().set(playerPath(uuid) + ".job", job == null ? "" : job.toUpperCase(Locale.ROOT));
    }

    public boolean setHome(UUID uuid, String name, Location location, int limit) {
        String cleanName = cleanName(name);
        String homesPath = playerPath(uuid) + ".homes";
        if (!storage.data().contains(homesPath + "." + cleanName)
                && getKeys(homesPath).size() >= limit) {
            return false;
        }
        writeLocation(homesPath + "." + cleanName, location);
        return true;
    }

    public Location getHome(UUID uuid, String name) {
        return readLocation(playerPath(uuid) + ".homes." + cleanName(name));
    }

    public boolean deleteHome(UUID uuid, String name) {
        String path = playerPath(uuid) + ".homes." + cleanName(name);
        if (!storage.data().contains(path)) {
            return false;
        }
        storage.data().set(path, null);
        return true;
    }

    public Set<String> getHomeNames(UUID uuid) {
        return getKeys(playerPath(uuid) + ".homes");
    }

    public void setWarp(String name, Location location) {
        writeLocation("warps." + cleanName(name), location);
    }

    public Location getWarp(String name) {
        return readLocation("warps." + cleanName(name));
    }

    public boolean deleteWarp(String name) {
        String path = "warps." + cleanName(name);
        if (!storage.data().contains(path)) {
            return false;
        }
        storage.data().set(path, null);
        return true;
    }

    public Set<String> getWarpNames() {
        return getKeys("warps");
    }

    public void save() {
        storage.save();
    }

    private String playerPath(UUID uuid) {
        return "players." + uuid;
    }

    private Set<String> getKeys(String path) {
        ConfigurationSection section = storage.data().getConfigurationSection(path);
        return section == null ? Collections.emptySet() : section.getKeys(false);
    }

    private String cleanName(String value) {
        return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "");
    }

    private void writeLocation(String path, Location location) {
        storage.data().set(path + ".world", location.getWorld().getName());
        storage.data().set(path + ".x", location.getX());
        storage.data().set(path + ".y", location.getY());
        storage.data().set(path + ".z", location.getZ());
        storage.data().set(path + ".yaw", location.getYaw());
        storage.data().set(path + ".pitch", location.getPitch());
    }

    private Location readLocation(String path) {
        String worldName = storage.data().getString(path + ".world");
        if (worldName == null) {
            return null;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(
                world,
                storage.data().getDouble(path + ".x"),
                storage.data().getDouble(path + ".y"),
                storage.data().getDouble(path + ".z"),
                (float) storage.data().getDouble(path + ".yaw"),
                (float) storage.data().getDouble(path + ".pitch")
        );
    }
}
