package de.econia.core.service;

import de.econia.core.EconiaCorePlugin;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.Player;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** Persistenter Direktmarkt für einzelne Gegenstände. */
public final class MarketService {
    private final EconiaCorePlugin plugin;
    private final YamlStorage storage;

    public MarketService(EconiaCorePlugin plugin, YamlStorage storage) {
        this.plugin = plugin;
        this.storage = storage;
    }

    public ListingResult listItem(Player seller, double price) {
        if (price <= 0.0D) {
            return ListingResult.error("Der Preis muss größer als 0 sein.");
        }
        ItemStack hand = seller.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR) {
            return ListingResult.error("Halte den Gegenstand in deiner Haupthand.");
        }
        ItemStack listed = hand.clone();
        listed.setAmount(1);
        if (hand.getAmount() == 1) {
            seller.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
        }
        String id = UUID.randomUUID().toString().substring(0, 8);
        String path = "listings." + id;
        storage.data().set(path + ".seller", seller.getUniqueId().toString());
        storage.data().set(path + ".seller-name", seller.getName());
        storage.data().set(path + ".price", price);
        storage.data().set(path + ".item", listed);
        storage.save();
        return ListingResult.success("Angebot #" + id + " wurde für " + String.format("%,.2f", price) + " Coins erstellt.");
    }

    public ListingResult buy(Player buyer, String id) {
        Listing listing = getListing(id);
        if (listing == null) {
            return ListingResult.error("Dieses Marktangebot existiert nicht.");
        }
        if (listing.seller().equals(buyer.getUniqueId())) {
            return ListingResult.error("Du kannst dein eigenes Angebot nicht kaufen.");
        }
        if (!plugin.getPlayerData().withdrawCoins(buyer.getUniqueId(), listing.price())) {
            return ListingResult.error("Du hast nicht genügend Coins.");
        }
        double feePercent = Math.max(0.0D, plugin.getConfig().getDouble("settings.market-listing-fee-percent", 5.0D));
        double earnings = listing.price() * (1.0D - feePercent / 100.0D);
        plugin.getPlayerData().addCoins(listing.seller(), earnings);
        for (ItemStack leftover : buyer.getInventory().addItem(listing.item().clone()).values()) {
            buyer.getWorld().dropItemNaturally(buyer.getLocation(), leftover);
        }
        storage.data().set("listings." + id, null);
        storage.save();
        return ListingResult.success("Du hast Angebot #" + id + " gekauft.");
    }

    public ListingResult cancel(Player seller, String id) {
        Listing listing = getListing(id);
        if (listing == null) {
            return ListingResult.error("Dieses Marktangebot existiert nicht.");
        }
        if (!listing.seller().equals(seller.getUniqueId()) && !seller.hasPermission("econia.admin")) {
            return ListingResult.error("Dieses Angebot gehört dir nicht.");
        }
        for (ItemStack leftover : seller.getInventory().addItem(listing.item().clone()).values()) {
            seller.getWorld().dropItemNaturally(seller.getLocation(), leftover);
        }
        storage.data().set("listings." + id, null);
        storage.save();
        return ListingResult.success("Angebot #" + id + " wurde zurückgenommen.");
    }

    public List<Listing> getListings() {
        ConfigurationSection section = storage.data().getConfigurationSection("listings");
        if (section == null) {
            return List.of();
        }
        List<Listing> listings = new ArrayList<>();
        for (String id : section.getKeys(false)) {
            Listing listing = getListing(id);
            if (listing != null) {
                listings.add(listing);
            }
        }
        listings.sort(Comparator.comparingDouble(Listing::price));
        return listings;
    }

    public void save() {
        storage.save();
    }

    private Listing getListing(String id) {
        String path = "listings." + id.toLowerCase();
        ItemStack item = storage.data().getItemStack(path + ".item");
        String sellerRaw = storage.data().getString(path + ".seller");
        if (item == null || sellerRaw == null) {
            return null;
        }
        try {
            return new Listing(id.toLowerCase(), UUID.fromString(sellerRaw),
                    storage.data().getString(path + ".seller-name", "Unbekannt"),
                    storage.data().getDouble(path + ".price"), item);
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    public record Listing(String id, UUID seller, String sellerName, double price, ItemStack item) {
        public String displayItem() {
            if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                return item.getItemMeta().getDisplayName();
            }
            return item.getType().name();
        }
    }

    public record ListingResult(boolean success, String message) {
        static ListingResult success(String message) {
            return new ListingResult(true, message);
        }

        static ListingResult error(String message) {
            return new ListingResult(false, message);
        }
    }
}
