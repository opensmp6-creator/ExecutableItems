package de.econia.core.service;

import de.econia.core.EconiaCorePlugin;
import de.econia.core.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Wertet die Strafgründe aus config.yml aus und speichert aktive Sperren dauerhaft. */
public final class PunishmentService {
    private final EconiaCorePlugin plugin;
    private final YamlStorage storage;

    public PunishmentService(EconiaCorePlugin plugin, YamlStorage storage) {
        this.plugin = plugin;
        this.storage = storage;
    }

    public String findReasonKey(String input) {
        String normalized = normalize(input);
        for (String key : getReasonKeys()) {
            if (normalize(key).equals(normalized) || normalize(plugin.getConfig().getString("punishments." + key + ".label", key)).equals(normalized)) {
                return key;
            }
        }
        return null;
    }

    public Set<String> getReasonKeys() {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("punishments");
        return section == null ? Set.of() : section.getKeys(false);
    }

    public String getReasonLabel(String key) {
        return plugin.getConfig().getString("punishments." + key + ".label", key);
    }

    public ActivePunishment punish(OfflinePlayer target, CommandSender actor, String reasonKey) {
        String type = plugin.getConfig().getString("punishments." + reasonKey + ".type", "TEMPBAN").toUpperCase(Locale.ROOT);
        String label = getReasonLabel(reasonKey);
        long expiresAt = 0L;
        if (type.equals("TEMPBAN")) {
            expiresAt = Instant.now().plus(parseDuration(plugin.getConfig().getString("punishments." + reasonKey + ".duration", "1d"))).toEpochMilli();
        }
        ActivePunishment punishment = new ActivePunishment(target.getUniqueId(), label, actor.getName(), type, expiresAt);
        if (!type.equals("KICK")) {
            String path = "bans." + target.getUniqueId();
            storage.data().set(path + ".reason", label);
            storage.data().set(path + ".actor", actor.getName());
            storage.data().set(path + ".type", type);
            storage.data().set(path + ".expires-at", expiresAt);
            storage.save();
        }
        Player online = Bukkit.getPlayer(target.getUniqueId());
        if (online != null) {
            online.kickPlayer(Text.color(punishment.disconnectMessage()));
        }
        return punishment;
    }

    public ActivePunishment getActive(UUID uuid) {
        String path = "bans." + uuid;
        if (!storage.data().contains(path)) {
            return null;
        }
        long expiresAt = storage.data().getLong(path + ".expires-at", 0L);
        if (expiresAt > 0L && expiresAt <= Instant.now().toEpochMilli()) {
            storage.data().set(path, null);
            storage.save();
            return null;
        }
        return new ActivePunishment(
                uuid,
                storage.data().getString(path + ".reason", "Unbekannter Grund"),
                storage.data().getString(path + ".actor", "Konsole"),
                storage.data().getString(path + ".type", "TEMPBAN"),
                expiresAt
        );
    }

    public void save() {
        storage.save();
    }

    private Duration parseDuration(String raw) {
        if (raw == null || raw.isBlank()) {
            return Duration.ofDays(1);
        }
        String value = raw.trim().toLowerCase(Locale.ROOT);
        try {
            long count = Long.parseLong(value.substring(0, value.length() - 1));
            return switch (value.charAt(value.length() - 1)) {
                case 'm' -> Duration.ofMinutes(count);
                case 'h' -> Duration.ofHours(count);
                case 'd' -> Duration.ofDays(count);
                case 'w' -> Duration.ofDays(count * 7L);
                default -> Duration.ofDays(1);
            };
        } catch (RuntimeException ignored) {
            return Duration.ofDays(1);
        }
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim()
                .toUpperCase(Locale.ROOT)
                .replace('Ä', 'A')
                .replace('Ö', 'O')
                .replace('Ü', 'U')
                .replace('ß', 'S')
                .replaceAll("[^A-Z0-9]+", "_")
                .replaceAll("^_+|_+$", "");
    }

    public record ActivePunishment(UUID target, String reason, String actor, String type, long expiresAt) {
        public String disconnectMessage() {
            if (type.equals("KICK")) {
                return "&cDu wurdest von &6Econia &cgekickt.\n&7Grund: &f" + reason;
            }
            String duration = expiresAt == 0L ? "&cPermanent" : "&e" + humanDuration();
            return "&cDu bist auf &6Econia &cgesperrt.\n&7Grund: &f" + reason
                    + "\n&7Dauer: " + duration
                    + "\n&7Teammitglied: &f" + actor;
        }

        private String humanDuration() {
            long minutes = Math.max(1L, ChronoUnit.MINUTES.between(Instant.now(), Instant.ofEpochMilli(expiresAt)));
            long days = minutes / 1440;
            long hours = (minutes % 1440) / 60;
            long remainingMinutes = minutes % 60;
            if (days > 0) {
                return days + " Tag(e), " + hours + " Stunde(n)";
            }
            if (hours > 0) {
                return hours + " Stunde(n), " + remainingMinutes + " Minute(n)";
            }
            return remainingMinutes + " Minute(n)";
        }
    }
}
