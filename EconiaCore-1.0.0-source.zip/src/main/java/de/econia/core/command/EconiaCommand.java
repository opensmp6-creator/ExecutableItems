package de.econia.core.command;

import de.econia.core.EconiaCorePlugin;
import de.econia.core.model.Rank;
import de.econia.core.service.MarketService;
import de.econia.core.service.PlotService;
import de.econia.core.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

/** Sämtliche Spieler-, Staff- und CityBuild-Befehle des Econia-Plugins. */
public final class EconiaCommand implements CommandExecutor, TabCompleter {
    private final EconiaCorePlugin plugin;
    private final Random random = new Random();

    public EconiaCommand(EconiaCorePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "punisch" -> punish(sender, args);
            case "rang" -> rank(sender, args);
            case "geld" -> coins(sender);
            case "gems" -> gems(sender);
            case "pay" -> pay(sender, args);
            case "eco" -> economy(sender, args);
            case "job" -> job(sender, args);
            case "markt" -> market(sender, args);
            case "kiste" -> crate(sender, args);
            case "plot" -> plot(sender, args);
            case "sethome" -> setHome(sender, args);
            case "home" -> home(sender, args);
            case "delhome" -> deleteHome(sender, args);
            case "setwarp" -> setWarp(sender, args);
            case "warp" -> warp(sender, args);
            case "delwarp" -> deleteWarp(sender, args);
            case "heal" -> heal(sender, args);
            case "fly" -> fly(sender, args);
            case "repair" -> repair(sender);
            default -> false;
        };
    }

    private boolean punish(CommandSender sender, String[] args) {
        if (!hasPunishPermission(sender)) {
            Text.error(sender, "Erst ab dem Rang Moderator darfst du Spieler bestrafen.");
            return true;
        }
        if (args.length < 2) {
            Text.error(sender, "Nutze: /punisch <Spielername> <Grund>");
            Text.info(sender, "Gründe: " + plugin.getPunishments().getReasonKeys().stream()
                    .map(plugin.getPunishments()::getReasonLabel).collect(Collectors.joining(", ")));
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (!target.isOnline() && !target.hasPlayedBefore()) {
            Text.error(sender, "Dieser Spieler ist unbekannt.");
            return true;
        }
        if (sender instanceof Player staff) {
            Rank actorRank = getRank(staff);
            Rank targetRank = plugin.getPlayerData().getRank(target.getUniqueId());
            if (!staff.hasPermission("econia.admin") && targetRank.getWeight(plugin.getConfig()) >= actorRank.getWeight(plugin.getConfig())) {
                Text.error(sender, "Du darfst keinen gleich- oder höherrangigen Spieler bestrafen.");
                return true;
            }
        }
        String reason = plugin.getPunishments().findReasonKey(String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
        if (reason == null) {
            Text.error(sender, "Unbekannter Grund. Nutze die Schreibweise aus /punisch ohne Argumente.");
            return true;
        }
        plugin.getPunishments().punish(target, sender, reason);
        Text.success(sender, target.getName() + " wurde bestraft: " + plugin.getPunishments().getReasonLabel(reason) + ".");
        return true;
    }

    private boolean rank(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Player player = player(sender);
            if (player != null) {
                Rank rank = getRank(player);
                Text.info(sender, "Dein Rang ist " + rank.getPrefix(plugin.getConfig()).trim() + "&7.");
            }
            return true;
        }
        if (args.length < 2) {
            Text.error(sender, "Nutze: /rang <Spieler> <Rang>");
            return true;
        }
        if (!hasRankPermission(sender)) {
            Text.error(sender, "Nur Administratoren und Owner dürfen Ränge setzen.");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (!target.isOnline() && !target.hasPlayedBefore()) {
            Text.error(sender, "Dieser Spieler ist unbekannt.");
            return true;
        }
        Rank targetRank = Rank.fromInput(args[1]);
        if (targetRank == null) {
            Text.error(sender, "Unbekannter Rang. Verfügbar: " + Arrays.stream(Rank.values()).map(Enum::name).collect(Collectors.joining(", ")));
            return true;
        }
        plugin.getPlayerData().ensurePlayer(target.getUniqueId(), target.getName() == null ? args[0] : target.getName());
        plugin.getPlayerData().setRank(target.getUniqueId(), targetRank);
        Player online = target.getPlayer();
        if (online != null) {
            plugin.getDisplays().refreshAll();
        }
        Text.success(sender, (target.getName() == null ? args[0] : target.getName()) + " hat jetzt den Rang " + targetRank.getDisplay(plugin.getConfig()) + "&a.");
        return true;
    }

    private boolean coins(CommandSender sender) {
        Player player = player(sender);
        if (player != null) {
            Text.info(player, "Du besitzt &6" + format(plugin.getPlayerData().getCoins(player.getUniqueId())) + " Coins&7.");
        }
        return true;
    }

    private boolean gems(CommandSender sender) {
        Player player = player(sender);
        if (player != null) {
            Text.info(player, "Du besitzt &b" + plugin.getPlayerData().getGems(player.getUniqueId()) + " Gems&7.");
        }
        return true;
    }

    private boolean pay(CommandSender sender, String[] args) {
        Player payer = player(sender);
        if (payer == null) {
            return true;
        }
        if (args.length != 2) {
            Text.error(payer, "Nutze: /pay <Spieler> <Betrag>");
            return true;
        }
        Player receiver = Bukkit.getPlayerExact(args[0]);
        double amount = amount(args[1]);
        if (receiver == null) {
            Text.error(payer, "Dieser Spieler ist nicht online.");
            return true;
        }
        if (receiver.equals(payer)) {
            Text.error(payer, "Du kannst dir selbst kein Geld überweisen.");
            return true;
        }
        if (amount <= 0.0D) {
            Text.error(payer, "Der Betrag muss größer als 0 sein.");
            return true;
        }
        if (!plugin.getPlayerData().withdrawCoins(payer.getUniqueId(), amount)) {
            Text.error(payer, "Du hast nicht genügend Coins.");
            return true;
        }
        plugin.getPlayerData().addCoins(receiver.getUniqueId(), amount);
        Text.success(payer, "Du hast " + format(amount) + " Coins an " + receiver.getName() + " überwiesen.");
        Text.success(receiver, "Du hast " + format(amount) + " Coins von " + payer.getName() + " erhalten.");
        plugin.getDisplays().refreshAll();
        return true;
    }

    private boolean economy(CommandSender sender, String[] args) {
        if (!hasEconomyPermission(sender)) {
            Text.error(sender, "Dafür fehlt dir die Berechtigung.");
            return true;
        }
        if (args.length != 4) {
            Text.error(sender, "Nutze: /eco <give|set> <Spieler> <coins|gems> <Betrag>");
            return true;
        }
        boolean set = args[0].equalsIgnoreCase("set");
        boolean give = args[0].equalsIgnoreCase("give");
        if (!set && !give) {
            Text.error(sender, "Nutze als Aktion give oder set.");
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (!target.isOnline() && !target.hasPlayedBefore()) {
            Text.error(sender, "Dieser Spieler ist unbekannt.");
            return true;
        }
        double value = amount(args[3]);
        if (value < 0.0D) {
            Text.error(sender, "Der Betrag darf nicht negativ sein.");
            return true;
        }
        plugin.getPlayerData().ensurePlayer(target.getUniqueId(), target.getName() == null ? args[1] : target.getName());
        String currency = args[2].toLowerCase(Locale.ROOT);
        if (currency.equals("coins") || currency.equals("geld")) {
            if (set) plugin.getPlayerData().setCoins(target.getUniqueId(), value); else plugin.getPlayerData().addCoins(target.getUniqueId(), value);
        } else if (currency.equals("gems")) {
            int gems = (int) Math.floor(value);
            if (set) plugin.getPlayerData().setGems(target.getUniqueId(), gems); else plugin.getPlayerData().addGems(target.getUniqueId(), gems);
        } else {
            Text.error(sender, "Währung muss coins oder gems sein.");
            return true;
        }
        Text.success(sender, "Kontostand von " + (target.getName() == null ? args[1] : target.getName()) + " wurde aktualisiert.");
        plugin.getDisplays().refreshAll();
        return true;
    }

    private boolean job(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        Set<String> jobs = configKeys("jobs");
        if (args.length == 0) {
            String active = plugin.getPlayerData().getJob(player.getUniqueId());
            Text.info(player, "Aktiver Job: " + (active.isBlank() ? "&ckeiner" : "&e" + active) + "&7. Verfügbar: " + String.join(", ", jobs));
            return true;
        }
        String selected = args[0].toUpperCase(Locale.ROOT);
        if (!jobs.contains(selected)) {
            Text.error(player, "Unbekannter Job. Verfügbar: " + String.join(", ", jobs));
            return true;
        }
        plugin.getPlayerData().setJob(player.getUniqueId(), selected);
        Text.success(player, "Du arbeitest nun als " + plugin.getConfig().getString("jobs." + selected + ".display", selected) + "&a.");
        return true;
    }

    private boolean market(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            List<MarketService.Listing> listings = plugin.getMarket().getListings();
            if (listings.isEmpty()) {
                Text.info(player, "Der Markt ist leer. Verkaufe dein gehaltenes Item mit /markt sell <Preis>.");
                return true;
            }
            Text.info(player, "&6Marktangebote &8(Preis, niedrig zuerst)&7:");
            listings.stream().limit(10).forEach(listing -> player.sendMessage(Text.color("&8#" + listing.id() + " &f" + listing.displayItem() + " &7von &e" + listing.sellerName() + " &7für &6" + format(listing.price()) + " Coins")));
            if (listings.size() > 10) Text.info(player, "Es gibt insgesamt " + listings.size() + " Angebote.");
            return true;
        }
        if (args[0].equalsIgnoreCase("sell") && args.length == 2) {
            result(player, plugin.getMarket().listItem(player, amount(args[1])));
            return true;
        }
        if (args[0].equalsIgnoreCase("buy") && args.length == 2) {
            result(player, plugin.getMarket().buy(player, args[1]));
            plugin.getDisplays().refreshAll();
            return true;
        }
        if (args[0].equalsIgnoreCase("cancel") && args.length == 2) {
            result(player, plugin.getMarket().cancel(player, args[1]));
            return true;
        }
        Text.error(player, "Nutze: /markt [list], /markt sell <Preis>, /markt buy <ID> oder /markt cancel <ID>");
        return true;
    }

    private boolean crate(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        String crate = args.length == 0 ? "STARTER" : args[0].toUpperCase(Locale.ROOT);
        if (!plugin.getConfig().contains("crates." + crate)) {
            Text.error(player, "Unbekannte Kiste. Verfügbar: " + String.join(", ", configKeys("crates")));
            return true;
        }
        int cost = plugin.getConfig().getInt("crates." + crate + ".gem-cost", 10);
        if (!plugin.getPlayerData().withdrawGems(player.getUniqueId(), cost)) {
            Text.error(player, "Du brauchst " + cost + " Gems für diese Kiste.");
            return true;
        }
        List<String> rewards = plugin.getConfig().getStringList("crates." + crate + ".rewards");
        if (rewards.isEmpty()) {
            plugin.getPlayerData().addGems(player.getUniqueId(), cost);
            Text.error(player, "Diese Kiste besitzt keine Belohnungen. Deine Gems wurden erstattet.");
            return true;
        }
        String[] reward = rewards.get(random.nextInt(rewards.size())).split(":", 2);
        Material material = Material.matchMaterial(reward[0]);
        int count = reward.length > 1 ? (int) Math.max(1, amount(reward[1])) : 1;
        if (material == null) {
            plugin.getPlayerData().addGems(player.getUniqueId(), cost);
            Text.error(player, "Die Kiste ist falsch konfiguriert. Deine Gems wurden erstattet.");
            return true;
        }
        for (ItemStack leftover : player.getInventory().addItem(new ItemStack(material, count)).values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), leftover);
        }
        Text.success(player, "Du hast " + count + "x " + material.name() + " aus der Kiste erhalten.");
        plugin.getDisplays().refresh(player);
        return true;
    }

    private boolean plot(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        if (args.length == 0) {
            Text.info(player, "Nutze: /plot claim, /plot info, /plot trust <Spieler>, /plot untrust <Spieler> oder /plot delete");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "claim" -> {
                PlotService.ClaimResult result = plugin.getPlots().claim(player);
                if (result.success()) Text.success(player, result.message()); else Text.error(player, result.message());
            }
            case "info" -> {
                PlotService.Plot plot = plugin.getPlots().getPlotAt(player.getLocation());
                if (plot == null) {
                    Text.info(player, "Hier befindet sich kein geschütztes Grundstück.");
                } else {
                    OfflinePlayer owner = Bukkit.getOfflinePlayer(plot.owner());
                    Text.info(player, "Plot von &e" + (owner.getName() == null ? plot.owner() : owner.getName()) + "&7: X " + plot.minX() + "–" + plot.maxX() + ", Z " + plot.minZ() + "–" + plot.maxZ() + ", Vertrauensliste: " + plot.trusted().size());
                }
            }
            case "delete" -> {
                if (plugin.getPlots().deleteAt(player)) Text.success(player, "Dein Grundstück wurde gelöscht. Es erfolgt keine Rückerstattung."); else Text.error(player, "Du stehst auf keinem eigenen Grundstück.");
            }
            case "trust" -> {
                if (args.length != 2) Text.error(player, "Nutze: /plot trust <Spieler>");
                else trustResult(player, plugin.getPlots().trust(player, args[1]));
            }
            case "untrust" -> {
                if (args.length != 2) Text.error(player, "Nutze: /plot untrust <Spieler>");
                else if (plugin.getPlots().untrust(player, args[1])) Text.success(player, args[1] + " wurde vom Grundstück entfernt."); else Text.error(player, "Spieler nicht berechtigt oder du stehst nicht auf deinem Plot.");
            }
            default -> Text.error(player, "Unbekannter Plot-Befehl.");
        }
        return true;
    }

    private boolean setHome(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        String name = args.length == 0 ? "home" : args[0];
        if (!validName(name)) {
            Text.error(player, "Der Name darf nur Buchstaben, Zahlen, _ und - enthalten.");
            return true;
        }
        Rank rank = getRank(player);
        if (!plugin.getPlayerData().setHome(player.getUniqueId(), name, player.getLocation(), rank.getHomes(plugin.getConfig()))) {
            Text.error(player, "Du hast dein Home-Limit von " + rank.getHomes(plugin.getConfig()) + " erreicht.");
            return true;
        }
        Text.success(player, "Home &e" + name.toLowerCase(Locale.ROOT) + " &awurde gesetzt.");
        return true;
    }

    private boolean home(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        if (args.length == 0) {
            Set<String> homes = plugin.getPlayerData().getHomeNames(player.getUniqueId());
            Text.info(player, homes.isEmpty() ? "Du hast keine Homes. Nutze /sethome <Name>." : "Deine Homes: " + String.join(", ", homes));
            return true;
        }
        Location location = plugin.getPlayerData().getHome(player.getUniqueId(), args[0]);
        if (location == null) {
            Text.error(player, "Dieses Home existiert nicht oder die Welt ist nicht geladen.");
            return true;
        }
        player.teleport(location);
        Text.success(player, "Du wurdest zu Home &e" + args[0].toLowerCase(Locale.ROOT) + " &ateleportiert.");
        return true;
    }

    private boolean deleteHome(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        if (args.length != 1) {
            Text.error(player, "Nutze: /delhome <Name>");
            return true;
        }
        if (plugin.getPlayerData().deleteHome(player.getUniqueId(), args[0])) Text.success(player, "Home gelöscht."); else Text.error(player, "Dieses Home existiert nicht.");
        return true;
    }

    private boolean setWarp(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        if (!hasWarpPermission(player)) {
            Text.error(player, "Nur Administratoren und Owner dürfen öffentliche Warps verwalten.");
            return true;
        }
        if (args.length != 1 || !validName(args[0])) {
            Text.error(player, "Nutze: /setwarp <Name> (Buchstaben, Zahlen, _ und -)");
            return true;
        }
        plugin.getPlayerData().setWarp(args[0], player.getLocation());
        Text.success(player, "Warp &e" + args[0].toLowerCase(Locale.ROOT) + " &awurde gesetzt.");
        return true;
    }

    private boolean warp(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        if (args.length == 0) {
            Set<String> warps = plugin.getPlayerData().getWarpNames();
            Text.info(player, warps.isEmpty() ? "Es sind noch keine Warps gesetzt." : "Warps: " + String.join(", ", warps));
            return true;
        }
        Location location = plugin.getPlayerData().getWarp(args[0]);
        if (location == null) {
            Text.error(player, "Dieser Warp existiert nicht oder die Welt ist nicht geladen.");
            return true;
        }
        player.teleport(location);
        Text.success(player, "Du wurdest zu Warp &e" + args[0].toLowerCase(Locale.ROOT) + " &ateleportiert.");
        return true;
    }

    private boolean deleteWarp(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        if (!hasWarpPermission(player)) {
            Text.error(player, "Nur Administratoren und Owner dürfen öffentliche Warps verwalten.");
            return true;
        }
        if (args.length != 1) {
            Text.error(player, "Nutze: /delwarp <Name>");
            return true;
        }
        if (plugin.getPlayerData().deleteWarp(args[0])) Text.success(player, "Warp gelöscht."); else Text.error(player, "Dieser Warp existiert nicht.");
        return true;
    }

    private boolean heal(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        Rank rank = getRank(player);
        if (!rank.isStaff() && !player.hasPermission("econia.staff.heal.others")) {
            Text.error(player, "Dieser Befehl ist Staff vorbehalten.");
            return true;
        }
        Player target = args.length == 0 ? player : Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            Text.error(player, "Dieser Spieler ist nicht online.");
            return true;
        }
        if (!target.equals(player) && !(rank == Rank.MODERATOR || rank == Rank.ADMINISTRATOR || rank == Rank.OWNER || player.hasPermission("econia.staff.heal.others"))) {
            Text.error(player, "Als Supporter kannst du nur dich selbst heilen.");
            return true;
        }
        target.setHealth(target.getMaxHealth());
        target.setFoodLevel(20);
        target.setSaturation(20.0F);
        Text.success(player, target.equals(player) ? "Du wurdest geheilt." : target.getName() + " wurde geheilt.");
        if (!target.equals(player)) Text.info(target, "Du wurdest von " + player.getName() + " geheilt.");
        return true;
    }

    private boolean fly(CommandSender sender, String[] args) {
        Player player = player(sender);
        if (player == null) return true;
        Rank rank = getRank(player);
        if (!rank.isStaff() && !player.hasPermission("econia.staff.fly.others")) {
            Text.error(player, "Dieser Befehl ist Staff vorbehalten.");
            return true;
        }
        Player target = args.length == 0 ? player : Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            Text.error(player, "Dieser Spieler ist nicht online.");
            return true;
        }
        if (!target.equals(player) && !(rank == Rank.MODERATOR || rank == Rank.ADMINISTRATOR || rank == Rank.OWNER || player.hasPermission("econia.staff.fly.others"))) {
            Text.error(player, "Als Supporter kannst du nur deinen eigenen Flugmodus ändern.");
            return true;
        }
        target.setAllowFlight(!target.getAllowFlight());
        target.setFlying(target.getAllowFlight());
        Text.success(player, "Flugmodus für " + target.getName() + " ist nun " + (target.getAllowFlight() ? "aktiviert" : "deaktiviert") + ".");
        return true;
    }

    private boolean repair(CommandSender sender) {
        Player player = player(sender);
        if (player == null) return true;
        Rank rank = getRank(player);
        if (!(rank == Rank.MODERATOR || rank == Rank.ADMINISTRATOR || rank == Rank.OWNER || player.hasPermission("econia.staff.repair"))) {
            Text.error(player, "Reparieren ist erst ab Moderator verfügbar.");
            return true;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() == Material.AIR || item.getType().getMaxDurability() <= 0) {
            Text.error(player, "Halte ein beschädigbares Item in der Haupthand.");
            return true;
        }
        item.setDurability((short) 0);
        Text.success(player, "Dein Item wurde repariert.");
        return true;
    }

    private boolean hasPunishPermission(CommandSender sender) {
        return sender.hasPermission("econia.punish") || !(sender instanceof Player player) || getRank(player).canPunish();
    }

    private boolean hasRankPermission(CommandSender sender) {
        return sender.hasPermission("econia.rank.set") || !(sender instanceof Player player) || getRank(player).canManageRanks();
    }

    private boolean hasEconomyPermission(CommandSender sender) {
        return sender.hasPermission("econia.economy.manage") || !(sender instanceof Player player) || getRank(player).canManageRanks();
    }

    private boolean hasWarpPermission(Player player) {
        return player.hasPermission("econia.warp.manage") || getRank(player).canManageRanks();
    }

    private Player player(CommandSender sender) {
        if (sender instanceof Player player) return player;
        Text.error(sender, "Dieser Befehl kann nur im Spiel verwendet werden.");
        return null;
    }

    private Rank getRank(Player player) {
        Rank rank = plugin.getPlayerData().getRank(player.getUniqueId());
        return rank == null ? Rank.SPIELER : rank;
    }

    private double amount(String raw) {
        try {
            return Double.parseDouble(raw.replace(',', '.'));
        } catch (NumberFormatException ignored) {
            return -1.0D;
        }
    }

    private boolean validName(String value) {
        return value != null && value.matches("[A-Za-z0-9_-]{1,24}");
    }

    private String format(double value) {
        return value == Math.rint(value) ? String.format("%,.0f", value) : String.format("%,.2f", value);
    }

    private Set<String> configKeys(String path) {
        org.bukkit.configuration.ConfigurationSection section = plugin.getConfig().getConfigurationSection(path);
        return section == null ? Set.of() : section.getKeys(false);
    }

    private void result(Player player, MarketService.ListingResult result) {
        if (result.success()) Text.success(player, result.message()); else Text.error(player, result.message());
    }

    private void trustResult(Player player, PlotService.TrustResult result) {
        if (result.success()) Text.success(player, result.message()); else Text.error(player, result.message());
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        List<String> options = switch (name) {
            case "punisch" -> args.length == 1 ? onlineNames() : args.length == 2 ? plugin.getPunishments().getReasonKeys().stream().map(key -> plugin.getPunishments().getReasonLabel(key).replace(' ', '-')).toList() : List.of();
            case "rang" -> args.length == 1 ? knownNames() : args.length == 2 ? Arrays.stream(Rank.values()).map(Enum::name).toList() : List.of();
            case "pay" -> args.length == 1 ? onlineNames() : List.of();
            case "eco" -> args.length == 1 ? List.of("give", "set") : args.length == 2 ? knownNames() : args.length == 3 ? List.of("coins", "gems") : List.of();
            case "job" -> args.length == 1 ? new ArrayList<>(configKeys("jobs")) : List.of();
            case "markt" -> args.length == 1 ? List.of("list", "sell", "buy", "cancel") : args.length == 2 && (args[0].equalsIgnoreCase("buy") || args[0].equalsIgnoreCase("cancel")) ? plugin.getMarket().getListings().stream().map(MarketService.Listing::id).toList() : List.of();
            case "kiste" -> args.length == 1 ? new ArrayList<>(configKeys("crates")) : List.of();
            case "plot" -> args.length == 1 ? List.of("claim", "info", "trust", "untrust", "delete") : args.length == 2 && (args[0].equalsIgnoreCase("trust") || args[0].equalsIgnoreCase("untrust")) ? knownNames() : List.of();
            case "home", "delhome" -> args.length == 1 && sender instanceof Player player ? new ArrayList<>(plugin.getPlayerData().getHomeNames(player.getUniqueId())) : List.of();
            case "warp", "delwarp" -> args.length == 1 ? new ArrayList<>(plugin.getPlayerData().getWarpNames()) : List.of();
            case "heal", "fly" -> args.length == 1 ? onlineNames() : List.of();
            default -> List.of();
        };
        String partial = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(partial)).sorted().toList();
    }

    private List<String> onlineNames() {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName).sorted().toList();
    }

    private List<String> knownNames() {
        return Arrays.stream(Bukkit.getOfflinePlayers()).map(OfflinePlayer::getName).filter(name -> name != null).sorted().toList();
    }
}
