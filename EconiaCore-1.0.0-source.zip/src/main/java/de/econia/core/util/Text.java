package de.econia.core.util;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

/** Einheitliche Minecraft-Farbcodes und Servernachrichten. */
public final class Text {
    private Text() {
    }

    public static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    public static void info(CommandSender sender, String message) {
        sender.sendMessage(color("&8[&6Econia&8] &7" + message));
    }

    public static void success(CommandSender sender, String message) {
        sender.sendMessage(color("&8[&6Econia&8] &a" + message));
    }

    public static void error(CommandSender sender, String message) {
        sender.sendMessage(color("&8[&6Econia&8] &c" + message));
    }
}
