# EconiaCore 1.0.0

**EconiaCore** ist ein eigenständig entwickeltes Paper-/Bukkit-kompatibles CityBuild-, Economy- und Moderationsplugin für den Server **Econia**. Es wurde von Grund auf implementiert und orientiert sich ausschließlich an deinem genannten Funktionsumfang; es enthält weder fremden Quellcode noch eine Kopie eines anderen Server-Plugins oder dessen Designs.

> **Zielplattform:** Paper für Minecraft Java **1.21.11** mit Java 21. Paper stellt eine Bukkit-kompatible Server-API bereit; für die Installation sollte daher ein passender Paper-Server eingesetzt werden. [1] [2]

| Artefakt | Zweck |
|---|---|
| `target/EconiaCore-1.0.0.jar` | Fertig kompiliertes Plugin, das auf den Server kommt. |
| `src/main/resources/config.yml` | Ränge, Prefixe, Limits, Strafgründe, Jobs, Kisten und Preise. |
| `players.yml` | Wird beim Start erzeugt und speichert Ränge, Coins, Gems, Jobs, Homes und Warps. |
| `punishments.yml` | Wird beim Start erzeugt und speichert aktive temporäre und permanente Sperren. |
| `plots.yml` | Wird beim Start erzeugt und speichert CityBuild-Grundstücke und Vertrauenslisten. |
| `market.yml` | Wird beim Start erzeugt und speichert Marktangebote. |

## Installation

Kopiere `EconiaCore-1.0.0.jar` in den Ordner `plugins/` deines **gestoppten** Paper-1.21.11-Servers. Starte den Server anschließend vollständig neu. Beim ersten Start erstellt das Plugin den Ordner `plugins/EconiaCore/` mitsamt `config.yml` und den Datendateien. Änderungen an `config.yml` übernimmst du mit einem Serverneustart.

Der erste Owner muss bereits einmal auf dem Server gewesen sein, damit sein Profil angelegt wurde. Weise ihm danach aus der Konsole oder als Server-OP den Rang zu:

```text
/rang Spielername OWNER
```

Danach kann der Owner weitere Teamränge direkt im Spiel setzen. Vor jeder Änderung an Rängen, Geldwerten oder Konfigurationen sollte der Ordner `plugins/EconiaCore/` gesichert werden.

## Rangsystem

Alle Prefixe erscheinen im **Chat**, in der **Tablist** und als Rangzeile im rechten Scoreboard. Das Scoreboard zeigt darüber hinaus Spielername, Coins, Gems und die Online-Spielerzahl an. Limits für Homes und Plots lassen sich je Rang in `config.yml` ändern.

| Spielerrang | Prefix ab Werk | Homes | Plots |
|---|---:|---:|---:|
| Spieler | `[Spieler]` | 1 | 1 |
| Premium | `[Premium]` | 2 | 2 |
| Diamond | `[Diamond]` | 3 | 3 |
| Ultra | `[Ultra]` | 4 | 4 |
| Legende | `[Legende]` | 5 | 5 |
| Supreme | `[Supreme]` | 6 | 6 |
| Platin | `[Platin]` | 8 | 8 |
| OP | `[OP]` | 20 | 12 |

| Teamrang | Berechtigungen innerhalb von EconiaCore |
|---|---|
| Supporter | Eigene Heilung und eigener Flugmodus. |
| Moderator | Kann ab diesem Rang `/punisch` verwenden, andere Spieler heilen bzw. fliegen lassen und Items reparieren. |
| Administrator | Moderationsrechte sowie Ränge, Economy und öffentliche Warps verwalten. |
| Owner | Vollzugriff auf sämtliche integrierten Funktionen. |

Die Zuordnung erfolgt über `/rang <Spieler> <Rang>`. Zusätzlich definiert `plugin.yml` die Knoten `econia.admin`, `econia.rank.set`, `econia.punish`, `econia.economy.manage`, `econia.warp.manage`, `econia.staff.heal.others`, `econia.staff.fly.others`, `econia.staff.repair` und `econia.plot.bypass`. Server-OPs erhalten diese administrativen Knoten standardmäßig. Die eigenen Rangprüfungen funktionieren auch ohne LuckPerms oder Vault.

## Bestrafungssystem

Ab **Moderator** ist der Befehl `/punisch <Spielername> <Grund>` freigeschaltet. Der Grund akzeptiert Schreibweisen mit Bindestrichen oder Leerzeichen, etwa:

```text
/punisch Spielername Griefing
/punisch Spielername Ausnutzen-von-Fehlern
/punisch Spielername Respektloses-Verhalten
```

Gleich- oder höherrangige Spieler können von einem Teammitglied nicht bestraft werden. Permanente und temporäre Sperren werden vor dem Login geprüft; abgelaufene temporäre Sperren werden automatisch entfernt. Die voreingestellten Sanktionen sind bewusst zentral in `config.yml` hinterlegt und können dort ohne Codeänderung an dein Regelwerk angepasst werden.

| Strafgrund | Standardaktion | Standarddauer |
|---|---|---:|
| Ausnutzen von Fehlern | Temporärer Bann | 7 Tage |
| Auszeit | Temporärer Bann | 2 Tage |
| Ban-Umgehung | Permanenter Bann | Permanent |
| Bauwerk | Temporärer Bann | 7 Tage |
| Beleidigung | Temporärer Bann | 2 Tage |
| Griefing | Temporärer Bann | 7 Tage |
| Hacking | Permanenter Bann | Permanent |
| HAUSVERBOT | Permanenter Bann | Permanent |
| Kick | Kick | – |
| Rechtsbruch | Temporärer Bann | 14 Tage |
| Respektloses Verhalten | Temporärer Bann | 1 Tag |
| Scamming | Temporärer Bann | 14 Tage |
| Sicherheitsbann | Permanenter Bann | Permanent |
| Wünsche | Temporärer Bann | 30 Tage |

## Economy, Jobs, Markt und Kisten

Neue Spieler erhalten standardmäßig **500 Coins** und **0 Gems**. Coins lassen sich mit `/pay` übertragen. Administratoren und Owner verwalten Guthaben mit `/eco give` oder `/eco set`. Der rechte Scoreboard-Bereich aktualisiert sich bei relevanten Economy-Aktionen.

| Bereich | Befehl | Verwendung |
|---|---|---|
| Kontostand | `/geld` oder `/money` | Zeigt Coins an. |
| Gems | `/gems` | Zeigt Gems an. |
| Überweisung | `/pay <Spieler> <Betrag>` | Überweist Coins an einen Online-Spieler. |
| Verwaltung | `/eco <give\|set> <Spieler> <coins\|gems> <Betrag>` | Administrator/Owner: setzt oder gibt Guthaben. |
| Jobs | `/job` | Zeigt den aktiven und alle verfügbaren Jobs. |
| Job wählen | `/job <Miner\|Farmer\|Holzfäller\|Fischer>` | Wählt genau einen Job. |
| Markt | `/markt` | Zeigt die bis zu zehn günstigsten Angebote an. |
| Verkaufen | `/markt sell <Preis>` | Listet ein Exemplar des gehaltenen Items. |
| Kaufen | `/markt buy <ID>` | Kauft ein Marktangebot. |
| Zurücknehmen | `/markt cancel <ID>` | Nimmt das eigene Angebot zurück. |
| Kiste | `/kiste [STARTER]` | Zieht gegen Gems eine zufällige konfigurierbare Belohnung. |

Der Miner erhält Coins für Diamanterz, der Farmer für Weizen, der Holzfäller für Eichenholz und der Fischer für Kabeljau. Material und Auszahlung jedes Jobs stehen unter `jobs:` in der Konfiguration. Beim Markt werden **5 %** Verkaufsgebühr abgezogen; auch dieser Wert ist anpassbar.

## CityBuild, Homes und Warps

Das CityBuild-System nutzt quadratische, standardmäßig **32 × 32 Blöcke** große Grundstücke. Mit `/plot claim` wird an der aktuellen Chunk-Kante ein Plot gekauft. Überlappende Grundstücke werden abgewiesen. Auf fremden Plots verhindert das Plugin Platzieren, Abbauen und Interaktionen; Eigentümer können Spieler gezielt freischalten.

| Bereich | Befehl | Verwendung |
|---|---|---|
| Plot kaufen | `/plot claim` | Kauft ein Grundstück für den konfigurierten Preis. |
| Plot prüfen | `/plot info` | Zeigt Besitzer, Koordinaten und Vertrauenslisten-Größe. |
| Spieler freischalten | `/plot trust <Spieler>` | Erlaubt Bauen und Interaktionen auf dem aktuellen eigenen Plot. |
| Freigabe entfernen | `/plot untrust <Spieler>` | Entfernt einen Spieler aus der Vertrauensliste. |
| Plot aufgeben | `/plot delete` | Löscht das aktuelle eigene Plot ohne Rückerstattung. |
| Home setzen | `/sethome [Name]` | Setzt ein persönliches Home. Ohne Namen heißt es `home`. |
| Home nutzen | `/home [Name]` | Ohne Namen zeigt der Befehl die Homes an. |
| Home löschen | `/delhome <Name>` | Löscht ein Home. |
| Warp setzen | `/setwarp <Name>` | Administrator/Owner: setzt einen öffentlichen Warp. |
| Warp nutzen | `/warp [Name]` | Ohne Namen zeigt der Befehl alle Warps an. |
| Warp löschen | `/delwarp <Name>` | Administrator/Owner: löscht einen Warp. |

## Staff-Werkzeuge

| Befehl | Mindestzugriff | Verhalten |
|---|---|---|
| `/heal [Spieler]` | Supporter für sich selbst; Moderator für andere | Füllt Leben, Hunger und Sättigung. |
| `/fly [Spieler]` | Supporter für sich selbst; Moderator für andere | Schaltet den Flugmodus um. |
| `/repair` | Moderator | Repariert das Item in der Haupthand. |

## Konfiguration und Grenzen

Die Datei `config.yml` ist die einzige Datei, die du regelmäßig bearbeiten musst. Dort stehen alle Rangfarben und Prefixe, Home-/Plot-Limits, Preis und Größe von Plots, Marktgebühr, Kistenbelohnungen, Jobs und Strafdauern. YAML-Einrückungen dürfen dabei nicht verändert werden.

Diese Version enthält bewusst ein schlankes, serverinternes System ohne externe Abhängigkeiten. Markt und Kisten werden über Befehle bedient, nicht über Inventar-GUIs. Für sehr große Netzwerke oder mehrere Serverinstanzen sollte die YAML-Ablage vor einem Produktiveinsatz durch eine zentrale Datenbank und ein Proxy-fähiges Synchronisationskonzept ersetzt werden.

## Build aus dem Quellcode

Im Projektordner genügt bei installiertem JDK 21 und Maven:

```bash
mvn clean package
```

Das Ergebnis liegt anschließend unter `target/EconiaCore-1.0.0.jar`. Der aktuelle Quellcode wurde erfolgreich mit der Paper-API `1.21.11-R0.1-SNAPSHOT` und Java 21 kompiliert.

## Referenzen

[1]: https://papermc.io/downloads/paper "PaperMC – Downloads"
[2]: https://docs.papermc.io/paper/dev/project-setup "PaperMC Docs – Plugin-Projekt einrichten"
